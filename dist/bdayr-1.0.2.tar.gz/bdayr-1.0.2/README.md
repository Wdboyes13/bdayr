# Read calendars with event name and mm/dd 
config file at ~/.config/rcal/config.json
```js
{
    'calpath': '~/path/to/calendar.ics'
}
```